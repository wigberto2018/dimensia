function change_p_visivility(id) {
  var el = document.getElementById(id);
  if (el.style.display == 'none' || el.style.display == '') el.style.display = 'block';
  else el.style.display = 'none';
}

